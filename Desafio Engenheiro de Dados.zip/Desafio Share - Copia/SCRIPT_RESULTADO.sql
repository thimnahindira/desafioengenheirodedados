-- O CAMPO 'FULLVISITID' FOI GERADO COM A JUNÇÃO DOS CAMPOS 'FULLVISITORID' E 'VISITID' FORMANDO UM ID UNICO:
SELECT FULLVISITORID || VISITID AS FULLVISITID
FROM TBDADOVISITANTE 
ORDER BY FULLVISITID;

/*
 O CAMPO HORAVISIT FOI CRIADO NA JUNÇÃO DOS CAMPOS hits.hour, 
hits.minute, hits.time E FAZ REFERENCIA AO HORARIO DA VISITA
*/				
SELECT hits.hour|| hits.minute || hits.time AS HORAVISIT
 
/*
 Contagem de Pageviews:
 Selecionando o numero total de PageViews:
 */
SELECT COUNT(Totals.pageviews) 
FROM TBRESULTADOSDAVISITA;

-- Selecionando o numero total de PageViews da Sessão mais Recente:
SELECT COUNT(Totals.pageviews) 
FROM TBRESULTADOSDAVISITA 
WHERE DATE =  MAX(DATE);


-- Selecionando o número de sessões por usuário;
SELECT FULLVISITID, VISITNUMBER
FROM TBDADOVISITANTE
ORDER BY FULLVISITID;

 -- Selecionando sessões distintas por data;
SELECT DISTINCT FULLVISITID, DATE 
FROM TBDADOVISITANTE
WHERE VISITNUMBER = 1 
ORDER BY DATE 

 -- Média de duração da sessão por data:
SELECT AVG (HORAVISIT) 
FROM TBDADOVISITANTE
WHERE VISITNUMBER = 1
ORDER BY DATE;

 -- Sessões diárias por tipo de browser;
SELECT DISTINCT A.DATE, COUNT(A.VisitNumber)
FROM TBDADOVISITANTE A
INNER JOIN TBDADOSDAVISITA B on A.FullVisitId = B.FullVisitId
GROUP BY B.DEVICE.BROWSER
ORDER BY DATE;
